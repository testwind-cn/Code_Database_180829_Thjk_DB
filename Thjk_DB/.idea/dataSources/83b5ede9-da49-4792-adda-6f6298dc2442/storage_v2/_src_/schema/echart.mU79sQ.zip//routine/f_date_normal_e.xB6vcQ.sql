create
    definer = root@localhost function f_date_normal_e(date_v date, date_s date, date_l int) returns date
BEGIN
	#Routine body goes here...
  #  date_s = '2015-08-03'

return 	`date_s`	+ INTERVAL (
	(
	(
	( ( to_days( `date_v` ) - to_days( `date_s` ) ) + ( ( to_days(`date_s`) DIV `date_l` ) * `date_l` ) ) DIV `date_l` 
	) * `date_l` 
	) + `date_l` - 1 - ( ( to_days(`date_s`) DIV `date_l` ) * `date_l` ) 
	) DAY ;
	
END;

