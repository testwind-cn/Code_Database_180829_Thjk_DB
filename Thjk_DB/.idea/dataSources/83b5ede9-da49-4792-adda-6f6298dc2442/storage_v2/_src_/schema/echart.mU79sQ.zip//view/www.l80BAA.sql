create definer = root@localhost view www as
select (to_days(`f_date_normal_e`('2019-09-03', '2019-08-03', 14)) - to_days(`f_date_normal_e`('2019-08-03', '2019-08-03', 14))) AS `Name_exp_1`,
       (`f_date_normal_e`('2019-09-13', '2019-08-03', 14) - `f_date_normal_e`('2019-08-03', '2019-08-03', 14))                   AS `Name_exp_2`,
       `f_date_normal_e`('2019-09-12', '2019-08-03', 14)                                                                         AS `f_date_normal_e ( '2019-09-12', '2019-08-03', 14 )`,
       `f_date_normal_e`('2019-08-03', '2019-08-03', 14)                                                                         AS `f_date_normal_e ( '2019-08-03', '2019-08-03', 14 )`,
       ('2019-8-13' - '2019-07-10')                                                                                              AS `'2019-8-13' - '2019-07-10'`;

