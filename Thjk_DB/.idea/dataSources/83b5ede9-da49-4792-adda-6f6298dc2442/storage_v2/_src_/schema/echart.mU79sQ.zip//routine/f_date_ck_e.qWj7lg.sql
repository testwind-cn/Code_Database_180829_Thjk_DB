create
    definer = root@localhost function f_date_ck_e(date1 date, date2 date, date_group_len int, ma_len int) returns tinyint(1)
BEGIN
	#Routine body goes here...
  # date1 -- dim date
	# date2 -- data date
	
	RETURN ( ( to_days( `date1` ) - to_days( `date2` ) ) < `date_group_len`* `ma_len`) 
	AND ( ( to_days( `date1` ) - to_days( `date2` ) ) >= 0 )  ;
END;

