create definer = root@localhost view v_group_14_pma5_e as
select `un_data1`.`date_v`           AS `tgroup`,
       (sum(`un_data1`.`c01`) / 5.0) AS `sum(全部结清-笔数) / 5`,
       (sum(`un_data1`.`c02`) / 5.0) AS `sum(全部结清-原始贷款本金) / 5`,
       (sum(`un_data1`.`c06`) / 5.0) AS `sum(全部未结清-笔数) / 5`,
       (sum(`un_data1`.`c07`) / 5.0) AS `sum(全部未结清-原始贷款本金) / 5`,
       (sum(`un_data1`.`c08`) / 5.0) AS `sum(逾期30天+-笔数) / 5`,
       (sum(`un_data1`.`c09`) / 5.0) AS `sum(逾期30天+原始贷款本金) / 5`,
       (sum(`un_data1`.`c10`) / 5.0) AS `sum(逾期30天+贷款余额.本金) / 5`,
       (sum(`un_data1`.`c11`) / 5.0) AS `sum(逾期90天+-笔数) / 5`,
       (sum(`un_data1`.`c12`) / 5.0) AS `sum(逾期90天+原始贷款本金) / 5`,
       (sum(`un_data1`.`c13`) / 5.0) AS `sum(逾期90天+贷款余额.本金) / 5`
from (select `dim_table`.`date_v` AS `date_v`,
             `data_table`.`c01`   AS `c01`,
             `data_table`.`c02`   AS `c02`,
             `data_table`.`c06`   AS `c06`,
             `data_table`.`c07`   AS `c07`,
             `data_table`.`c08`   AS `c08`,
             `data_table`.`c09`   AS `c09`,
             `data_table`.`c10`   AS `c10`,
             `data_table`.`c11`   AS `c11`,
             `data_table`.`c12`   AS `c12`,
             `data_table`.`c13`   AS `c13`
      from (((select `dim_date_14_e`.`date_v` AS `date_v` from `echart`.`dim_date_14_e` where ((`dim_date_14_e`.`date_v` >= str_to_date('2015-08-03', '%Y-%m-%d')) and (`dim_date_14_e`.`date_v` <= str_to_date('2019-05-01', '%Y-%m-%d'))) order by `dim_date_14_e`.`date_v`)) `dim_table`
               left join (select `v_group_14_e`.`tgroup` AS `tgroup`,
                                 `v_group_14_e`.`c01`    AS `c01`,
                                 `v_group_14_e`.`c02`    AS `c02`,
                                 `v_group_14_e`.`c06`    AS `c06`,
                                 `v_group_14_e`.`c07`    AS `c07`,
                                 `v_group_14_e`.`c08`    AS `c08`,
                                 `v_group_14_e`.`c09`    AS `c09`,
                                 `v_group_14_e`.`c10`    AS `c10`,
                                 `v_group_14_e`.`c11`    AS `c11`,
                                 `v_group_14_e`.`c12`    AS `c12`,
                                 `v_group_14_e`.`c13`    AS `c13`
                          from `echart`.`v_group_14_e`
                          order by `v_group_14_e`.`tgroup`) `data_table` on (`f_date_ck_e`(`dim_table`.`date_v`, `data_table`.`tgroup`, 14, 5)))) `un_data1`
group by `un_data1`.`date_v`
order by `un_data1`.`date_v`;

