create definer = root@localhost view v_group_14_e as
select `un_data`.`tgroup`   AS `tgroup`,
       sum(`un_data`.`c01`) AS `c01`,
       sum(`un_data`.`c02`) AS `c02`,
       sum(`un_data`.`c06`) AS `c06`,
       sum(`un_data`.`c07`) AS `c07`,
       sum(`un_data`.`c08`) AS `c08`,
       sum(`un_data`.`c09`) AS `c09`,
       sum(`un_data`.`c10`) AS `c10`,
       sum(`un_data`.`c11`) AS `c11`,
       sum(`un_data`.`c12`) AS `c12`,
       sum(`un_data`.`c13`) AS `c13`
from ((select `f_date_normal_e`(`echart`.`d0009`.`col_08`, '2015-08-03', 14)           AS `tgroup`,
              0                                                                        AS `c01`,
              0                                                                        AS `c02`,
              sum(1)                                                                   AS `c06`,
              sum(`echart`.`d0009`.`col_10`)                                           AS `c07`,
              sum(if((`echart`.`d0009`.`col_47` >= 30), 1, 0))                         AS `c08`,
              sum(if((`echart`.`d0009`.`col_47` >= 30), `echart`.`d0009`.`col_10`, 0)) AS `c09`,
              sum(if((`echart`.`d0009`.`col_47` >= 30), `echart`.`d0009`.`col_40`, 0)) AS `c10`,
              sum(if((`echart`.`d0009`.`col_47` >= 90), 1, 0))                         AS `c11`,
              sum(if((`echart`.`d0009`.`col_47` >= 90), `echart`.`d0009`.`col_10`, 0)) AS `c12`,
              sum(if((`echart`.`d0009`.`col_47` >= 90), `echart`.`d0009`.`col_40`, 0)) AS `c13`
       from `echart`.`d0009`
       where (`echart`.`d0009`.`data_dt` = '2019-04-04')
       group by `f_date_normal_e`(`echart`.`d0009`.`col_08`, '2015-08-03', 14))
      union all
      (select `f_date_normal_e`(`echart`.`d0010`.`col_08`, '2015-08-03', 14) AS `tgroup`, sum(1) AS `c01`, sum(`echart`.`d0010`.`col_10`) AS `c0`, 0 AS `c06`, 0 AS `c07`, 0 AS `c08`, 0 AS `c09`, 0 AS `c10`, 0 AS `c11`, 0 AS `c12`, 0 AS `c12` from `echart`.`d0010` where (`echart`.`d0010`.`data_dt` = '2019-04-04') group by `f_date_normal_e`(`echart`.`d0010`.`col_08`, '2015-08-03', 14))) `un_data`
group by `un_data`.`tgroup`
order by `un_data`.`tgroup`;

