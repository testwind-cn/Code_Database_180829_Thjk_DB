create definer = root@localhost view dim_date_14_e as
select `f_date_normal_e`(`echart`.`dim_date`.`date_v`, '2015-08-03', 14) AS `date_v`
from `echart`.`dim_date`
where ((`echart`.`dim_date`.`date_v` >= str_to_date('2015-01-05', '%Y-%m-%d')) and (`echart`.`dim_date`.`date_v` <= str_to_date('2020-05-01', '%Y-%m-%d')))
group by `f_date_normal_e`(`echart`.`dim_date`.`date_v`, '2015-08-03', 14);

