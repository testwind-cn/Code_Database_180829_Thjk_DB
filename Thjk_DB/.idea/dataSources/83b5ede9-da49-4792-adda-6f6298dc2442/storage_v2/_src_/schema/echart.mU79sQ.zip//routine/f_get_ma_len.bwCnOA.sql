create
    definer = root@localhost function f_get_ma_len(date_v date, date_s date, date_l int, ma_len int) returns float(7, 3)
BEGIN
	#Routine body goes here...
	DECLARE len float(7,3) DEFAULT 1.0;
set len= (( to_days( `f_date_normal_e` ( `date_v`, `date_s`, `date_l`  ) ) - to_days( `f_date_normal_e` ( `date_s`, `date_s`, `date_l`  ) ) ) div `date_l` ) + 1.0 ;

IF len > `ma_len` THEN
	set len= `ma_len`;
END IF;
IF len < 1.0 THEN
		set len= 1.0;
END IF;

	RETURN len;
END;

